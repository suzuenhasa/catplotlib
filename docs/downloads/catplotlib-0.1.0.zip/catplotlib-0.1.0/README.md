# Catplotlib

A working Matplotlib theme and vector cat toolkit. This is the first **0.1.0**
implementation of the Catplotlib playground, not a replacement plotting engine.

## Install

Unzip this project, open a terminal in its folder, then run:

```sh
python -m pip install .
python examples/quickstart.py
```

Requires Python 3.10+ and Matplotlib 3.10+. Tested here on Matplotlib 3.10.8 and
NumPy 2.3.5. The package has **not been published to PyPI**; do not assume that a
package with this name on a registry is this project.

## Keep your existing plotting code

```python
import matplotlib.pyplot as plt
import catplotlib as cp

with cp.context("milk_tea"):
    fig, ax = plt.subplots()
    line, = ax.plot([0, 1, 2, 3], [2, 5, 4, 8])
    cp.catify(line, companion="nugget", size=30)
    ax.set(xlabel="Time (naps)", ylabel="Mood (purrs)")
    ax.margins(y=.2)
    fig.savefig("purrs.svg")
    plt.show()
```

`cp.use()` applies the theme globally to new plots. `cp.context()` restores
settings when its block exits. Importing Catplotlib does not change rcParams.
For a style sheet alone: `plt.style.use("catplotlib.catplotlib")`.

## What the skin does

The style controls the paper and axes backgrounds, categorical colour cycle,
grid, lines, ticks, typography, legends and export settings. It works with
ordinary Matplotlib plot types, including plots created through pandas or
Seaborn when they respect rcParams. Explicit colours and later Seaborn themes
can override it. It styles new artists; it does not retroactively recolour an
existing figure, alter data, replace axes, or monkey-patch Matplotlib.

Four palettes: `milk_tea`, `strawberry`, `blueberry`, `matcha`.

Use `cp.cmap("milk_tea")` for sequential data, `kind="diverging"` for data
centred around a meaningful midpoint, or `kind="warm"` for the orange heat map.
Colormaps are opt-in because a decorative categorical palette is not an
appropriate default for every scalar field.

## The cat layer

| Helper | Purpose |
| --- | --- |
| `cp.cat(ax, (.9, .9), ...)` | A fixed-size cat annotation, defaulting to axes-fraction coordinates. |
| `cp.cat(ax, (x, y), coords="data", ...)` | A cat attached to a 2D data position through zoom, pan and log transforms. |
| `cp.catify(line, every=1, ...)` | Add cats to an existing 2D `Line2D`. Returns removable artists. |
| `cp.perch(bars, ...)` | Cats at vertical or horizontal bar endpoints, including negative bars. |
| `cp.paw_marker()` | A true `Path` marker usable with `plot`, `scatter`, `stem`, and similar methods. |

Choose `companion="mochi"`, `"beans"`, `"nugget"`, or `"tofu"`, and
`mood="happy"`, `"sleepy"`, or `"surprised"`. Sizes are in points, independent
of data coordinates. The original 12 SVG faces are bundled. The renderer uses
Matplotlib paths and ellipses, so cats remain vectors in SVG/PDF; PNG is also
supported. There is no browser, SVG conversion dependency, or network request.

Multicolour cats require individual artists. `catify` refuses more than 80 cats
by default; use `every=10` or efficient single-colour paw markers for dense data.
Annotations added with `catify` follow axis transforms but are snapshots of the
line's data: remove/recreate them after `line.set_data()` or in an animation.
3D plots support decorative cats in axes coordinates; projected 3D cat markers
and animated faces are not implemented. Give edge markers room with margins.
Custom cats in legends are not automatic.

## 52 plot recipes

```python
from catplotlib.gallery import PLOTS, draw, code
import matplotlib.pyplot as plt

fig, ax = draw("violinplot", seed=7, palette_name="strawberry")
plt.show()
print(code("surface"))  # complete Python source for a 3D surface
print([p["id"] for p in PLOTS])
```

The gallery covers all **37 entries in Matplotlib's main plot-types overview**,
plus 15 common variants and specialist plots:

- Everyday: line, scatter, vertical/horizontal bars, stem, step, filled bands,
  stacked areas, stairs, grouped/stacked bars, waterfall.
- Statistics: histogram, box, error bars, violin, event raster, 2D histogram,
  hexbin, pie, ECDF, donut.
- Fields: image, pseudocolour mesh, contour/filled contour, quiver, barbs,
  streamlines, sparse-matrix spy and matrix heat map.
- Unstructured: triangular contour/filled contour, tripcolor and triangulation.
- 3D: line, scatter, bars, ribbon, quiver, stem, surface, triangular surface,
  wireframe and voxels.
- Special: polar, radar, Sankey, interval/Gantt, spectrogram, PSD and log-log.

This is coverage of that catalogue and common examples, not a claim to
implement every possible composition in Matplotlib's much larger example
gallery. Statistical computations and axes remain Matplotlib's responsibility.

The website uses two pre-rendered sample datasets and four palettes for this
extended gallery. Its six original plots remain live browser demonstrations.
The Python package accepts your real data. 3D website previews are SVG snapshots;
interactive 3D rotation is available through Matplotlib's normal GUI backends.

## Validation

```sh
python -m unittest discover -s tests -v
```

Checks cover restoration of style settings, true vector SVG/PDF export for all
12 cat faces, unchanged line data and limits, log-axis positioning, horizontal
and negative bars, the dense-data guard, and rendering all 52 examples.

## Design references

- [Matplotlib style sheets](https://matplotlib.org/stable/api/style_api.html)
- [Artists as annotations](https://matplotlib.org/stable/gallery/text_labels_and_annotations/demo_annotation_box.html)
- [Matplotlib plot types](https://matplotlib.org/stable/plot_types/index.html)

No Matplotlib source files are replaced. The included artwork and examples were
created for this Catplotlib project. Choose your preferred project license
before distributing it as a public package.
