"""Catplotlib: a theme and artist toolkit for ordinary Matplotlib."""
from .theme import PALETTES, palette, cmap, rc, use, context
from .artists import COMPANIONS, MOODS, cat, catify, perch, paw_marker

__version__ = "0.1.0"
__all__ = ["PALETTES", "COMPANIONS", "MOODS", "palette", "cmap", "rc", "use", "context", "cat", "catify", "perch", "paw_marker"]
