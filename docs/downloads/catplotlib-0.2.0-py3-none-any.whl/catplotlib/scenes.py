"""Playful vector poses that interact with a chart's geometry.

3D positions are projected on every draw, so a cat stays attached when the
Matplotlib camera moves. The cat itself is an illustrated 2D billboard.
"""
from functools import lru_cache
from importlib.resources import files
import math
import xml.etree.ElementTree as ET
import numpy as np
from matplotlib.offsetbox import AnnotationBbox, DrawingArea
from matplotlib.patches import PathPatch, Ellipse
from matplotlib.transforms import Affine2D
from mpl_toolkits.mplot3d import proj3d
from .artists import _read_components, _ids, COMPANIONS

POSES = ("belly_up", "swat", "lounging")
_COATS = {
    "mochi": ("#a4a19d", "#73716e", "#fff8e8"),
    "beans": ("#55515b", "#34313a", "#eeece4"),
    "nugget": ("#f0bc6d", "#d7924e", "#fff1ca"),
    "tofu": ("#fffaf0", "#e3d5c8", "#fffaf0"),
}
_SIZES = {"belly_up": (230, 165, (118, 141)), "swat": (170, 220, (84, 205)), "lounging": (230, 155, (114, 112))}

def _head(companion, mood, transform):
    root = ET.fromstring((files("catplotlib") / "assets" / f"{companion}-{mood}.svg").read_text())
    return f'<g transform="{transform}">' + ''.join(ET.tostring(c, encoding="unicode") for c in root) + '</g>'

@lru_cache(maxsize=12)
def pose_svg(companion="mochi", pose="belly_up"):
    """Return a standalone SVG of a pose; this is also the Python artist source."""
    if companion not in COMPANIONS: raise ValueError(f"companion must be one of {COMPANIONS}")
    if pose not in POSES: raise ValueError(f"pose must be one of {POSES}")
    coat, shade, cream = _COATS[companion]
    width, height, _ = _SIZES[pose]
    ink = "#49423f"
    if pose == "belly_up":
        art = f'''
        <ellipse cx="122" cy="149" rx="93" ry="7" fill="#d9ccb9" opacity=".38" stroke="none"/>
        <path d="M179 120q38 18 39-11 0-17-11-20-10-1-10 8 14 0 10 14-4 9-24-3" fill="{coat}"/>
        <path d="M81 85q33-20 77-5 37 12 36 37-4 30-61 27-55 0-63-27" fill="{coat}"/>
        <ellipse cx="131" cy="111" rx="49" ry="26" fill="{cream}" stroke="none"/>
        <path d="M158 88q5-22 18-25 13-4 18 4 6 10-12 17l-7 13" fill="{coat}"/>
        <ellipse cx="184" cy="69" rx="11" ry="9" fill="{coat}"/>
        <ellipse cx="184" cy="71" rx="5" ry="3.7" fill="#e99ba3" stroke="none"/>
        <path d="M174 122q12-5 20 0 10 8 3 14-10 6-24-1" fill="{coat}"/>
        <path d="M187 131l2 5m4-7 2 5" fill="none" stroke-width="1.5"/>
        <path d="M96 90Q89 77 88 55l-4-13q-2-12 9-12 10 1 9 13l2 14q5 17 12 29" fill="{coat}"/>
        <ellipse cx="92" cy="33" rx="11" ry="13" fill="{coat}"/>
        <ellipse cx="92" cy="35" rx="5.6" ry="5.8" fill="#e99ba3" stroke="none"/>
        <circle cx="86" cy="26" r="2.2" fill="#e99ba3" stroke="none"/><circle cx="93" cy="23" r="2.2" fill="#e99ba3" stroke="none"/><circle cx="99" cy="28" r="2.2" fill="#e99ba3" stroke="none"/>
        <path d="M124 89q10-19 9-37-3-13 5-18 11-5 14 5 3 13-5 24l-5 23" fill="{coat}"/>
        <ellipse cx="145" cy="37" rx="10" ry="12" fill="{coat}" transform="rotate(20 145 37)"/>
        <ellipse cx="145" cy="39" rx="5" ry="5.8" fill="#e99ba3" stroke="none"/><circle cx="139" cy="30" r="2" fill="#e99ba3" stroke="none"/><circle cx="146" cy="27" r="2" fill="#e99ba3" stroke="none"/><circle cx="151" cy="32" r="2" fill="#e99ba3" stroke="none"/>
        <path d="M117 109q3-3 6 0m4 8q3 3 6 0" fill="none" stroke="{shade}" stroke-width="1.4" opacity=".45"/>
        <path d="m160 86-5 8m16-4-5 7m-54 33 3 8m11-7 2 8" stroke="{shade}" stroke-width="4" fill="none" opacity=".65"/>
        {_head(companion, 'surprised', 'translate(10 73) rotate(-24 39 37) scale(.79)')}
        <path d="m70 26-6-7m20-7-1-8m74 15 5-8m2 22 9-2" fill="none" stroke="#b49ad2" stroke-width="2"/>
        '''
    elif pose == "swat":
        art = f'''
        <ellipse cx="85" cy="208" rx="66" ry="6" fill="#d9ccb9" opacity=".4" stroke="none"/>
        <path d="M55 185q-39 14-38-12 0-12 10-14 10 1 6 10-4 13 24 1" fill="{coat}"/>
        <path d="M65 114q-23 18-25 54-3 34 33 38 48 0 53-24 2-38-26-68" fill="{coat}"/>
        <ellipse cx="82" cy="170" rx="26" ry="31" fill="{cream}" stroke="none"/>
        <path d="M105 137q24-22 31-55l5-22q3-13-6-15-11-3-15 13l-5 24-23 28" fill="{coat}"/>
        <ellipse cx="136" cy="48" rx="13" ry="16" fill="{coat}" transform="rotate(16 136 48)"/>
        <ellipse cx="136" cy="51" rx="6" ry="7" fill="#e99ba3" stroke="none"/><circle cx="129" cy="40" r="2.5" fill="#e99ba3" stroke="none"/><circle cx="137" cy="37" r="2.5" fill="#e99ba3" stroke="none"/><circle cx="145" cy="43" r="2.5" fill="#e99ba3" stroke="none"/>
        <path d="M58 137q-14 14-9 33 5 10 15 3l13-11" fill="{coat}"/>
        <path d="m52 161 6 2m-5 5 7 1" fill="none" stroke-width="1.5"/>
        <path d="M55 190q-15 1-16 11-1 10 23 7l8-8m29-10q-13 5-8 15 9 8 26-1 6-7-4-13" fill="{coat}"/>
        <path d="M50 201v6m6-6v6m44-3 2 4m5-6 2 4" fill="none" stroke-width="1.5"/>
        <path d="m43 160 9 3m-9 8 10 1m59-12-9 4m10 7-9 3" fill="none" stroke="{shade}" stroke-width="4" opacity=".7"/>
        {_head(companion, 'surprised', 'translate(38 72) rotate(-16 40 37) scale(.82)')}
        <path d="m113 30-8-7m32-5 2-10m14 26 9-6" fill="none" stroke="#ef9dac" stroke-width="2.2"/>
        '''
    else:
        art = f'''
        <path d="M172 100q40 10 38-13-2-15-14-17-10 0-8 9 13 3 10 10-3 7-24-4" fill="{coat}"/>
        <path d="M72 80q50-26 96-2 25 11 18 29-6 12-43 12H85q-26-2-25-17" fill="{coat}"/>
        <path d="M105 100q33-5 53 11l-61 4" fill="{cream}" stroke="none"/>
        <path d="M160 95q-17 3-9 14 5 7 20 1" fill="none"/>
        <path d="m144 75-4 10m16-6-4 10m18-5-6 9" fill="none" stroke="{shade}" stroke-width="4.5" opacity=".7"/>
        <path d="M74 100q5 22-7 39-9 10-17 1-2-7 5-17l1-21m34 0q9 20 0 34-6 10-16 3-5-6 2-17" fill="{coat}"/>
        <path d="m54 133 7 4m17-8 8 3" fill="none" stroke-width="1.5"/>
        {_head(companion, 'happy', 'translate(16 37) rotate(9 44 40) scale(.89)')}
        <path d="m185 41 3-7 3 7 7 3-7 3-3 7-3-7-7-3Z" fill="#ef9dac" stroke="none"/>
        '''
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="{companion} {pose.replace("_", " ")}"><g stroke="{ink}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none">{art}</g></svg>'

class _ProjectedCat(AnnotationBbox):
    """An AnnotationBbox anchored to a 3D data position on each render."""
    def __init__(self, area, xyz, **kwargs):
        self.xyz = tuple(xyz)
        super().__init__(area, (0, 0), xycoords="data", **kwargs)

    def draw(self, renderer):
        x, y, _ = proj3d.proj_transform(*self.xyz, self.axes.get_proj())
        self.xy = (x, y)
        super().draw(renderer)

def pose(ax, xy, *, pose="belly_up", companion="mochi", size=100,
         coords="data", offset=(0, 0), mirror=False, zorder=100):
    """Place a full-body vector cat. size is its width in points.

    xy takes two data coordinates on 2D axes or three on 3D axes. With
    coords='axes fraction', use two fractions on either. The ground/perch
    point of the illustration is anchored to xy; mirror swaps its facing.
    Returns one removable artist. This does not change data or axis limits.
    """
    svg = pose_svg(companion, pose)
    if not math.isfinite(size) or size <= 0: raise ValueError("size must be finite and positive")
    if coords not in ("data", "axes fraction"): raise ValueError("coords must be data or axes fraction")
    dimensions = 3 if getattr(ax, "name", "") == "3d" and coords == "data" else 2
    if np.shape(xy) != (dimensions,) or not np.isfinite(xy).all():
        raise ValueError(f"xy must contain {dimensions} finite coordinates")
    w, h, anchor = _SIZES[pose]
    scale = size / w
    area = DrawingArea(size, h * scale, 0, 0)
    flip = Affine2D().scale(-scale if mirror else scale, -scale).translate(size if mirror else 0, h*scale)
    for kind, geometry, a, matrix in _read_components(ET.fromstring(svg)):
        kw = dict(facecolor=a.get("fill", "none"), edgecolor=a.get("stroke", "none"), linewidth=float(a["stroke-width"])*scale, alpha=float(a.get("opacity", 1)), capstyle="round", joinstyle="round")
        patch = PathPatch(geometry, **kw) if kind == "path" else Ellipse(geometry[:2], geometry[2]*2, geometry[3]*2, **kw)
        patch.set_transform(Affine2D(matrix) + flip + area.get_transform())
        area.add_artist(patch)
    alignment = ((1-anchor[0]/w) if mirror else anchor[0]/w, 1-anchor[1]/h)
    kw = dict(xybox=offset, boxcoords="offset points", box_alignment=alignment, frameon=False, pad=0, annotation_clip=False, zorder=zorder)
    artist = _ProjectedCat(area, xy, **kw) if dimensions == 3 else AnnotationBbox(area, xy, xycoords=coords, **kw)
    artist.set_gid(f"catplotlib-cat-scene-{next(_ids)}")
    artist.set_in_layout(False)
    ax.add_artist(artist)
    return artist

def mesh_cat(ax, xyz=(0, -1.8, -1.25), *, companion="mochi", size=125):
    """A belly-up cat beneath a 3D wire mesh. Set z-limits to leave room."""
    if getattr(ax, "name", "") != "3d": raise ValueError("mesh_cat requires a 3D Axes")
    return pose(ax, xyz, pose="belly_up", companion=companion, size=size)

def cat_duel(ax, floor, roof, *, ground="mochi", top="nugget", ground_size=65,
             top_size=67, ground_offset=(0,0), top_offset=(0,0), mirror=True):
    """A reaching cat below a smug lounging cat. Anchors may be 2D or 3D."""
    lower = pose(ax, floor, pose="swat", companion=ground, size=ground_size, mirror=mirror, offset=ground_offset)
    upper = pose(ax, roof, pose="lounging", companion=top, size=top_size, offset=top_offset)
    return lower, upper
