"""Run after installation: python examples/quickstart.py"""
import matplotlib.pyplot as plt
import catplotlib as cp

with cp.context("milk_tea"):
    fig, ax = plt.subplots(figsize=(8, 5))
    line, = ax.plot([0, 1, 2, 3, 4, 5], [2, 3.7, 6.4, 5.2, 8.8, 9.8])
    cp.catify(line, companion="nugget", size=30)
    ax.set(xlabel="Time (naps)", ylabel="Mood (purrs)", title="A little data. A lot of cat.")
    ax.margins(y=.15)
    fig.tight_layout()
    fig.savefig("my-cat-plot.svg")
    fig.savefig("my-cat-plot.png")
    plt.show()
